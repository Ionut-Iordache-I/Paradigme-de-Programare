{-
	PP Project 2021

	This is where you will write the implementation for the given tasks.
	You can add other modules aswell.
-}

module Tasks where

import Dataset
import Text.Printf
import Data.List


type CSV = String
type Value = String
type Row = [Value]
type Table = [Row]

{-
	TASK SET 1
-}

readFloat' :: String -> Float
readFloat' "" = 0.0
readFloat' elem = (read elem) :: Float

readInteger' :: String -> Integer
readInteger' "" = 0
readInteger' elem = (read elem) :: Integer

readInt' :: String -> Int
readInt' "" = 0
readInt' elem = (read elem) :: Int

-- Task 1
compute_exam_grades :: Table -> Table
compute_exam_grades = map requestedFormat'

l1' = ["Riley Jackson","2","2","2","2","2","1","Ex. Scris"]
l1'' = ["Kinsley Miles","","","","","","","0.13"]
l1''' = ["","","","","",""]


-- functie ce intoarce formatul cerut pentru o lista
requestedFormat' :: Row -> Row
requestedFormat' l 
    | last(l) == "Ex. Scris" = ["Nume"] ++ ["Punctaj Exam"]
    | otherwise = [head(l)] ++ [printf "%.2f" (formula' l)]

-- formula de calcul enuntata (sumInteger')/4+Ex.scris unde sumInteger' este (Q1+Q2+Q3+Q4+Q5+Q6)
formula' :: Row -> Float
formula' l = (fromIntegral(sumInteger' (init (tail l))) / 4) + (readFloat' (last l))

-- calculeaza suma elementelor unei liste cu elemete Integer
sumInteger' :: Row -> Integer
sumInteger' l = 
    foldl (\acc elem -> if (elem == []) then acc else (readInteger' elem) + acc) 0 l

l2' = [["Olivia Noah","0","0","2","2","2","2","0.93"],
    ["Riley Jackson","2","2","2","2","2","1","1.2"],
    ["Elizabeth Nathan","1","1","2","1","0","2","0.8"],
    ["Kinsley Miles","","","","","","","0.13"]]

-- Task 2
-- Number of students who have passed the exam:
get_passed_students_num :: Table -> Int
get_passed_students_num = 
    foldl (\acc l -> if((readFloat' (last(l))) > 2.50) then acc + 1 else acc) 0 .
    tail .
    compute_exam_grades


-- Percentage of students who have passed the exam:
get_passed_students_percentage :: Table -> Float
get_passed_students_percentage = printFunction' . calculatePercentage'

-- formula pentru determinarea procentajului de studenti care au trecut
calculatePercentage' :: Table -> Float
calculatePercentage' l = 
    fromIntegral(get_passed_students_num l) / fromIntegral((length l) - 1) 

-- functie de afisare ca float cu 2 zecimale
printFunction' :: Float -> Float
printFunction' x = read (printf "%.2f" x) :: Float

-- Average exam grade
get_exam_avg :: Table -> Float
get_exam_avg = printFunction' . computeAvg'

computeSum' :: Table -> Float
computeSum' list = foldl (\acc l -> ((readFloat' (last l))) + acc) 0.0 (tail list)

computeAvg' :: Table -> Float
computeAvg' l = printFunction'(computeSum' (compute_exam_grades l)) / fromIntegral((length l) - 1)

-- Number of students who gained at least 1.5p from homework:
get_passed_hw_num :: Table -> Int
get_passed_hw_num = checkCond'

-- verificarea conditiei si returnarea numarului de studenti cu temele in valoare de "minim" 1.5p
checkCond' :: Table -> Int
checkCond' list = 
    foldl (\acc l -> if ((printFunction' (hwTotalT1T2T3' l)) >= 1.5) then acc + 1 else acc) 0 (tail(list))

-- functia care calculeza suma celor 3 teme
hwTotalT1T2T3' :: Row -> Float
hwTotalT1T2T3' l = sumFloat' (take 3 (tail(tail l)))

-- calculeaza suma elementelor unei liste cu elemete Float
sumFloat' :: Row -> Float
sumFloat' l = 
    foldl (\acc elem -> if (elem == []) then acc else (readFloat' elem) + acc) 0.0 l

-- Task 3
get_avg_responses_per_qs :: Table -> Table
get_avg_responses_per_qs = showInFormat3'

-- calculeaza suma punctajelor pentru o intrebare Qx
-- getSumQx' :: Int -> Table -> Integer
-- getSumQx' pos list = foldl (\acc l -> (readInteger' (l !! pos)) + acc) 0 list

-- functia ce intoarce lista in formatul conform task-ului
showInFormat3' :: Table -> Table
showInFormat3' list = [(init(tail(head list)))] ++ [(map show (createAvgList' list))]

-- functia care intoarce o lista de integer reprezentand sumele totale ale intrebarilor
createAvgList' :: Table -> [Float]
createAvgList' list = 
    foldr (avg) [] (init (tail (tran' (tail(list)))))
    where avg = \l acc -> (printFunction'(fromIntegral(sumInteger'(l)) / 
                          fromIntegral((length list) - 1))):acc

-- functie care efectueaza transpunerea unei matrice
tran' :: [[a]] -> [[a]]
tran' ([]:_) = []
tran' m = (map head m) : tran' (map tail m)

-- Task 4
-- intoarce Tabelul in formatul specificat
get_exam_summary :: Table -> Table
get_exam_summary tab = ["Q","0","1","2"]:(adjustList' (createLists' (init(tail(tran'(tail(tab)))))) 1)

-- converteste o lista de Integer la o lista de String
integerListToRow' :: [Integer] -> Row
integerListToRow' = foldr (\elem acc -> (show elem):acc) []

-- creeaza lista cu numarul de elemente de 0, 1 si 2 din lista initiala
createList' :: Row -> [Integer]
createList' = foldr (\elem acc -> 
            if(readInteger'(elem) == 0) then ((head acc) + 1):(tail acc) 
            else if(readInteger'(elem) == 1) then (head acc):(head(tail acc) + 1):[last acc]
                 else (init acc)++[(last acc) + 1]) [0, 0, 0]

-- aplica tuturor listelor din tabel functia anterioara convertind listele la [String]
createLists' :: Table -> Table
createLists' = foldr (\list acc -> integerListToRow'(createList' list):acc) []

-- adauga Qx (unde x este 1..6) la fiecare lista din tabel
adjustList' :: Table -> Integer -> Table 
adjustList' [] y = []
adjustList' (x:xs) y = (("Q" ++ (show y)):x) : (adjustList' xs (y + 1))

-- Task 5
get_ranking :: Table -> Table
get_ranking res = ["Nume","Punctaj Exam"]:(sortStudents' $tail(compute_exam_grades res))

-- functii de comparare pentru nume si pentru medie
compareGrades [name1, grade1] [name2, grade2]
    | grade1 < grade2 = LT
    | grade1 > grade2 = GT
    | otherwise = EQ

compareNames [name1, grade1] [name2, grade2]
    | name1 < name2 = LT
    | name1 > name2 = GT
    | otherwise = EQ

-- sortare dupa nume si medie
sortStudents' :: Table -> Table
sortStudents' l = sortBy compareGrades (sortBy compareNames l)

-- Task 6
get_exam_diff_table :: Table -> Table
get_exam_diff_table res = ["Nume","Punctaj interviu","Punctaj scris","Diferenta"] :
            (sortBy compareDiff (sortBy compareNames1 (map requestedFormat6' (tail res))))

-- formula de calcul enuntata (sumInteger')/4 unde sumInteger' este (Q1+Q2+Q3+Q4+Q5+Q6)
formula6' :: Row -> Float
formula6' l = fromIntegral(sumInteger' (init (tail l))) / 4

-- functie ce intoarce formatul cerut pentru o lista
requestedFormat6' :: Row -> Row
requestedFormat6' l = [head(l)] ++ [printf "%.2f" (formula6' l)] ++ 
                  [printf "%.2f" (readFloat' (last l))] ++ 
                  [printf "%.2f" (abs((formula6' l) - (readFloat' (last l))))]

-- functii de comparare pentru nume si pentru
--  diferenta a 2 numere din liste de tipul specificat
compareDiff [name1, interview1, write1, diff1] [name2, interview2, write2, diff2]
    | diff1 < diff2 = LT
    | diff1 > diff2 = GT
    | otherwise = EQ

compareNames1 [name1, interview1, write1, diff1] [name2, interview2, write2, diff2]
    | name1 < name2 = LT
    | name1 > name2 = GT
    | otherwise = EQ