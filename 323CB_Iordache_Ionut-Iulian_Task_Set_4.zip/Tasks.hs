{-
	PP Project 2021

	This is where you will write the implementation for the given tasks.
	You can add other modules aswell.
-}

{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE FlexibleInstances #-}

module Tasks where

import Dataset
import Text.Printf
import Data.List
import Data.Maybe

type CSV = String
type Value = String
type Row = [Value]
type Table = [Row]

{-
	TASK SET 1
-}

readFloat' :: String -> Float
readFloat' "" = 0.0
readFloat' elem = (read elem) :: Float

readInteger' :: String -> Integer
readInteger' "" = 0
readInteger' elem = (read elem) :: Integer

readInt' :: String -> Int
readInt' "" = 0
readInt' elem = (read elem) :: Int

-- Task 1
compute_exam_grades :: Table -> Table
compute_exam_grades = map requestedFormat'

l1' = ["Riley Jackson","2","2","2","2","2","1","Ex. Scris"]
l1'' = ["Kinsley Miles","","","","","","","0.13"]
l1''' = ["","","","","",""]


-- auxFunctie ce intoarce formatul cerut pentru o lista
requestedFormat' :: Row -> Row
requestedFormat' l 
    | last(l) == "Ex. Scris" = ["Nume"] ++ ["Punctaj Exam"]
    | otherwise = [head(l)] ++ [printf "%.2f" (formula' l)]

-- formula de calcul enuntata (sumInteger')/4+Ex.scris unde sumInteger' este (Q1+Q2+Q3+Q4+Q5+Q6)
formula' :: Row -> Float
formula' l = (fromIntegral(sumInteger' (init (tail l))) / 4) + (readFloat' (last l))

-- calculeaza suma elementelor unei liste cu elemete Integer
sumInteger' :: Row -> Integer
sumInteger' l = 
    foldl (\acc elem -> if (elem == []) then acc else (readInteger' elem) + acc) 0 l

l2' = [["Olivia Noah","0","0","2","2","2","2","0.93"],
    ["Riley Jackson","2","2","2","2","2","1","1.2"],
    ["Elizabeth Nathan","1","1","2","1","0","2","0.8"],
    ["Kinsley Miles","","","","","","","0.13"]]

-- Task 2
-- Number of students who have passed the exam:
get_passed_students_num :: Table -> Int
get_passed_students_num = 
    foldl (\acc l -> if((readFloat' (last(l))) > 2.50) then acc + 1 else acc) 0 .
    tail .
    compute_exam_grades


-- Percentage of students who have passed the exam:
get_passed_students_percentage :: Table -> Float
get_passed_students_percentage = printauxFunction' . calculatePercentage'

-- formula pentru determinarea procentajului de studenti care au trecut
calculatePercentage' :: Table -> Float
calculatePercentage' l = 
    fromIntegral(get_passed_students_num l) / fromIntegral((length l) - 1) 

-- auxFunctie de afisare ca float cu 2 zecimale
printauxFunction' :: Float -> Float
printauxFunction' x = read (printf "%.2f" x) :: Float

-- Average exam grade
get_exam_avg :: Table -> Float
get_exam_avg = printauxFunction' . computeAvg'

computeSum' :: Table -> Float
computeSum' list = foldl (\acc l -> ((readFloat' (last l))) + acc) 0.0 (tail list)

computeAvg' :: Table -> Float
computeAvg' l = printauxFunction'(computeSum' (compute_exam_grades l)) / fromIntegral((length l) - 1)

-- Number of students who gained at least 1.5p from homework:
get_passed_hw_num :: Table -> Int
get_passed_hw_num = checkCond'

-- verificarea conditiei si returnarea numarului de studenti cu temele in valoare de "minim" 1.5p
checkCond' :: Table -> Int
checkCond' list = 
    foldl (\acc l -> if ((printauxFunction' (hwTotalT1T2T3' l)) >= 1.5) then acc + 1 else acc) 0 (tail(list))

-- auxFunctia care calculeza suma celor 3 teme
hwTotalT1T2T3' :: Row -> Float
hwTotalT1T2T3' l = sumFloat' (take 3 (tail(tail l)))

-- calculeaza suma elementelor unei liste cu elemete Float
sumFloat' :: Row -> Float
sumFloat' l = 
    foldl (\acc elem -> if (elem == []) then acc else (readFloat' elem) + acc) 0.00 l

-- Task 3
get_avg_responses_per_qs :: Table -> Table
get_avg_responses_per_qs = showInFormat3'

-- calculeaza suma punctajelor pentru o intrebare Qx
-- getSumQx' :: Int -> Table -> Integer
-- getSumQx' pos list = foldl (\acc l -> (readInteger' (l !! pos)) + acc) 0 list

-- auxFunctia ce intoarce lista in formatul conform task-ului
showInFormat3' :: Table -> Table
showInFormat3' list = [(init(tail(head list)))] ++ [(map show (createAvgList' list))]

-- auxFunctia care intoarce o lista de integer reprezentand sumele totale ale intrebarilor
createAvgList' :: Table -> [Float]
createAvgList' list = 
    foldr (avg) [] (init (tail (tran' (tail(list)))))
    where avg = \l acc -> (printauxFunction'(fromIntegral(sumInteger'(l)) / 
                          fromIntegral((length list) - 1))):acc

-- auxFunctie care efectueaza transpunerea unei matrice
tran' :: [[a]] -> [[a]]
tran' ([]:_) = []
tran' m = (map head m) : tran' (map tail m)

-- Task 4
-- intoarce Tabelul in formatul specificat
get_exam_summary :: Table -> Table
get_exam_summary tab = ["Q","0","1","2"]:(adjustList' (createLists' (init(tail(tran'(tail(tab)))))) 1)

-- converteste o lista de Integer la o lista de String
integerListToRow' :: [Integer] -> Row
integerListToRow' = foldr (\elem acc -> (show elem):acc) []

-- creeaza lista cu numarul de elemente de 0, 1 si 2 din lista initiala
createList' :: Row -> [Integer]
createList' = foldr (\elem acc -> 
            if(readInteger'(elem) == 0) then ((head acc) + 1):(tail acc) 
            else if(readInteger'(elem) == 1) then (head acc):(head(tail acc) + 1):[last acc]
                 else (init acc)++[(last acc) + 1]) [0, 0, 0]

-- aplica tuturor listelor din tabel auxFunctia anterioara convertind listele la [String]
createLists' :: Table -> Table
createLists' = foldr (\list acc -> integerListToRow'(createList' list):acc) []

-- adauga Qx (unde x este 1..6) la fiecare lista din tabel
adjustList' :: Table -> Integer -> Table 
adjustList' [] y = []
adjustList' (x:xs) y = (("Q" ++ (show y)):x) : (adjustList' xs (y + 1))

-- Task 5
get_ranking :: Table -> Table
get_ranking res = ["Nume","Punctaj Exam"]:(sortStudents' $tail(compute_exam_grades res))

-- auxFunctii de comparare pentru nume si pentru medie
compareGrades [name1, grade1] [name2, grade2]
    | grade1 < grade2 = LT
    | grade1 > grade2 = GT
    | otherwise = EQ

compareNames [name1, grade1] [name2, grade2]
    | name1 < name2 = LT
    | name1 > name2 = GT
    | otherwise = EQ

-- sortare dupa nume si medie
sortStudents' :: Table -> Table
sortStudents' l = sortBy compareGrades (sortBy compareNames l)

-- Task 6
get_exam_diff_table :: Table -> Table
get_exam_diff_table res = ["Nume","Punctaj interviu","Punctaj scris","Diferenta"] :
            (sortBy compareDiff (sortBy compareNames1 (map requestedFormat6' (tail res))))

-- formula de calcul enuntata (sumInteger')/4 unde sumInteger' este (Q1+Q2+Q3+Q4+Q5+Q6)
formula6' :: Row -> Float
formula6' l = fromIntegral(sumInteger' (init (tail l))) / 4

-- auxFunctie ce intoarce formatul cerut pentru o lista
requestedFormat6' :: Row -> Row
requestedFormat6' l = [head(l)] ++ [printf "%.2f" (formula6' l)] ++ 
                  [printf "%.2f" (readFloat' (last l))] ++ 
                  [printf "%.2f" (abs((formula6' l) - (readFloat' (last l))))]

-- auxFunctii de comparare pentru nume si pentru
--  diferenta a 2 numere din liste de tipul specificat
compareDiff [name1, interview1, write1, diff1] [name2, interview2, write2, diff2]
    | diff1 < diff2 = LT
    | diff1 > diff2 = GT
    | otherwise = EQ

compareNames1 [name1, interview1, write1, diff1] [name2, interview2, write2, diff2]
    | name1 < name2 = LT
    | name1 > name2 = GT
    | otherwise = EQ

-- ================================================================================================
-- Task Set 2

test0 = "\
    \Nume,Q1,Q2,Q3,Q4,Q5,Q6,Ex. Scris\n\
    \Olivia Noah,0,0,2,2,2,2,0.93\n\
    \Kinsley Miles,,,,,,,0.13\n\
    \Joshua Kennedy,1,2,2,2,1,2,0.67"

-- auxFunctie de split in auxFunctie de caracter dat ca param.
splitBy :: Char -> String -> [String] 
splitBy ch = foldr (\elem acc -> if (elem == ch) then []:acc
             else (elem:(head acc)) : (tail acc)) [[]] 

-- auxFunctie de transformare din csv in tipul Table
read_csv :: CSV -> Table
read_csv csv = map (splitBy ',') $ splitBy '\n' $ csv

rowToValue :: Row -> Value
rowToValue = init . foldr (\elem acc -> (elem ++ ',' : acc)) ""

-- auxFunctie de transformare din tipul table in csv
write_csv :: Table -> CSV
write_csv = init . foldr (\elem acc -> (rowToValue elem) ++ '\n' : acc) ""

-- lista ce contine capetele de tabel al listelor din Dataset.hs
namesListOfLists = [hw_grades!!0, exam_grades!!0, lecture_grades!!0]

-- Task 1
as_list :: String -> Table -> [String]
as_list colName table = map (!!(getElemPos' colName (head table))) (tail table)

-- determina prima pozitie pe care apare un element dat ca param. intr-o lista
-- cu cel putin un elem.
getElemPos' :: String -> Row -> Int
getElemPos' str (x:xs) = head(elemIndices str (x:xs))

-- Task 2
tsort :: String -> Table -> Table
tsort str1 table1 = auxSort' str1 (auxSort' (head(head table1)) table1)

-- realizeaza sortarea unui tabel in functie de un element continut de
-- listele acestuia
auxSort' :: String -> Table -> Table
auxSort' str table = (head table) :
    (sortBy (\list1 list2 -> compare (list1!!(getElemPos' str (head table))) 
    (list2!!(getElemPos' str (head table)))) (tail table))

-- Task 3
vmap :: (Value -> Value) -> Table -> Table
vmap auxFunction table = map (\list -> map auxFunction list) table
-- An example use of this would be:
-- correct_exam_table = value_map (\x -> if x == "" then "0" else x) exam_grades

-- Task 4
rmap :: (Row -> Row) -> [String] -> Table -> Table
rmap auxFunction namesList table = namesList : (map auxFunction (tail table))

l4' = ["Olivia Noah","0.42","0.49","1","1.05","","","0",""]
l4'' = ["Emma Aiden","","0.5","1","0.9","","","0",""]

get_hw_grade_total :: Row -> Row
get_hw_grade_total row = (head row) : [printf "%.2f" ((sumFloat' (tail(tail row))) :: Float) :: String]

-- Task 5
vunion :: Table -> Table -> Table
vunion t1 t2 = if ((head t1) == (head t2)) then t1 ++ (tail t2) else t1

-- Task 6
hunion :: Table -> Table -> Table
hunion t1 t2
    | (length t1) > (length t2) = 
        zipWith (++) t1 (t2 ++ (replicate ((length t1) - (length t2)) (replicate (length (head t2)) "")))
    | (length t1) < (length t2) = 
        zipWith (++) (t1 ++ (replicate ((length t2) - (length t1)) (replicate (length (head t1)) ""))) t2
    | otherwise = zipWith (++) t1 t2

a1 = ["Nume","Lab (1p)","T1 (0.5p)","T2 (1p)","T3 (1.5p)","Ex1 (0.25p)","Ex2 (0.25p)","Ex3 (0.25p)","Ex4 (0.25p)"]
a2 = ["Nume","Q1","Q2","Q3","Q4","Q5","Q6","Ex. Scris"]
b1 = ["a","b","c","d"]
b2 = ["a","b","c"]

-- Task 7
-- fac join pe tabele inlaturand coloana str care este identica din cel de-al 2-lea tabel
tjoin :: String -> Table -> Table -> Table
tjoin str t1 t2 = keyJoin' str t1 t2

keyJoin' :: Value -> Table -> Table -> Table
keyJoin' str t1 t2 = ((head t1) ++ (removeVal' str (head t2))) :
    (foldr (\x acc -> if (x `elem` (as_list str t2)) then
        ((t1!!(findPos' x str t1)) ++ (tail(t2!!(findPos' x str t2)))) : acc else
        ((t1!!(findPos' x str t1))++(replicate ((length (head t2))-1) "")) : acc) [] (as_list str t1))

-- gasesc pozitia, la care adaug 1, intr-o lista din tabel
findPos' :: Value -> Value -> Table -> Int
findPos' x str tab = (getElemPos' x (as_list str tab)) + 1

-- elimin un element dat dintr-o lista
removeVal' :: Value -> Row -> Row
removeVal' str row = foldr (\elem acc -> if (elem == str) then acc else elem : acc) [] row

-- sa ma mai uit la functie odata (intoarce o lista cu coloanele comune din cele 2 tabele)
intersect_t1_t2' :: Row -> Row -> Row
intersect_t1_t2' xs ys = foldr (\x acc -> if (x `elem` ys) then x:acc else acc) [] xs


-- folosind Task9 projection puteam obtine lista cu coloane pe care sa le elimin din tabel

-- intoarce tabelul fara coloana specificata
createSimpleTable' :: String -> Table -> Table
createSimpleTable' str table = 
    tran' (foldr (\list acc -> if ((head list) == str) then acc else list : acc) [] (tran' table))

-- Task 8
cartesian :: (Row -> Row -> Row) -> [String] -> Table -> Table -> Table
cartesian func' nList t1 t2 = 
    nList : map (\list -> func' (head list) (last list)) (sequence [tail t1, tail t2])

-- Task 9
projection :: [String] -> Table -> Table
projection nList table = tran' (foldr (\name acc -> (getEntireColumn' name table) : acc) [] nList)

-- intoarce o coloana inclusiv denumirea acesteia spre deosebire de task 1;
-- se foloseste de getElemPos' de la task 1
getEntireColumn' :: String -> Table -> [String]
getEntireColumn' colName table = map (!!(getElemPos' colName (head table))) table

-- ================================================================================================
-- Task Set 3

data Query =
    FromCSV CSV
    | ToCSV Query
    | AsList String Query
    | Sort String Query
    | ValueMap (Value -> Value) Query
    | RowMap (Row -> Row) [String] Query
    | VUnion Query Query
    | HUnion Query Query
    | TableJoin String Query Query
    | Cartesian (Row -> Row -> Row) [String] Query Query
    | Projection [String] Query
    | forall a. FEval a => Filter (FilterCondition a) Query
    | Graph EdgeOp Query

data QResult = CSV CSV | Table Table | List [String]
-- don't confuse first 'CSV' and second 'CSV': first refers to constructor name,
-- second refers to type CSV (defined in taskset 1); same with 'Table'.

instance Show QResult where
    show (CSV csv) = show csv
    show (Table table) = write_csv table
    show (List list) = show list

class Eval a where
    eval :: a -> QResult

-- functie de transformare a unui QResul in Table
qResToTable' :: QResult -> Table
qResToTable' (Table tab) = tab

-- inrolarea tipului Query in clasa eval
instance Eval Query where
    eval (FromCSV str) = Table (read_csv str)
    eval (ToCSV query) = CSV (write_csv(qResToTable'(eval query)))
    eval (AsList colname query) = List (as_list colname (qResToTable'(eval query)))
    eval (Sort colname query) = Table (tsort colname (qResToTable'(eval query)))
    eval (ValueMap op query) = Table (vmap op (qResToTable'(eval query)))
    eval (RowMap op colnames query) = Table (rmap op colnames (qResToTable'(eval query)))
    eval (VUnion query1 query2) = 
        Table (vunion (qResToTable'(eval query1)) (qResToTable'(eval query2)))
    eval (HUnion query1 query2) = 
        Table (hunion (qResToTable'(eval query1)) (qResToTable'(eval query2)))
    eval (TableJoin colname query1 query2) = 
        Table (tjoin colname (qResToTable'(eval query1)) (qResToTable'(eval query2)))
    eval (Cartesian op colnames query1 query2) = 
        Table (cartesian op colnames (qResToTable'(eval query1)) (qResToTable'(eval query2)))
    eval (Projection colnames query) = 
        Table (projection colnames (qResToTable'(eval query)))
    eval (Filter cond query) = 
        Table ((head (qResToTable'(eval query))) : (foldr (\row acc -> 
            if ((feval (head (qResToTable'(eval query))) cond row) == True) then row : acc 
            else acc) [] (tail $ qResToTable'(eval query))))
    eval (Graph edgeop query) = 
        Table (delEqRows'(modifiedTab' edgeop (qResToTable'(eval query))))

data FilterCondition a =
    Eq String a |
    Lt String a |
    Gt String a |
    In String [a] |
    FNot (FilterCondition a) |
    FieldEq String String

type FilterOp = Row -> Bool

class FEval a where
    feval :: [String] -> (FilterCondition a) -> FilterOp

instance FEval Float where
    feval colNames (Eq colname ref) = 
        (\row -> (readFloat'(row!!(getElemPos' colname colNames))) == ref)
    feval colNames (Lt colname ref) = 
        (\row -> (readFloat'(row!!(getElemPos' colname colNames))) < ref)
    feval colNames (Gt colname ref) = 
        (\row -> (readFloat'(row!!(getElemPos' colname colNames))) > ref)
    feval colNames (In colname list) = 
        (\row -> (readFloat'(row!!(getElemPos' colname colNames)) `elem` list) == True)
    
    feval colNames (FNot (Eq colname ref)) = 
        (\row -> not((readFloat'(row!!getElemPos' colname colNames)) == ref))
    feval colNames (FNot (Lt colname ref)) = 
        (\row -> not((readFloat'(row!!getElemPos' colname colNames)) < ref))
    feval colNames (FNot (Gt colname ref)) = 
        (\row -> not((readFloat'(row!!getElemPos' colname colNames)) > ref))
    feval colNames (FNot (In colname list)) = 
        (\row -> not((readFloat'(row!!(getElemPos' colname colNames)) `elem` list) == True))

    feval colNames (FieldEq colname1 colname2) = 
        (\row -> (readFloat'(row!!(getElemPos' colname1 colNames))) == (readFloat'(row!!(getElemPos' colname2 colNames))))

instance FEval String where
    feval colNames (Eq colname ref) = 
        (\row -> (row!!(getElemPos' colname colNames)) == ref)
    feval colNames (Lt colname ref) = 
        (\row -> (row!!(getElemPos' colname colNames)) < ref)
    feval colNames (Gt colname ref) = 
        (\row -> (row!!(getElemPos' colname colNames)) > ref)
    feval colNames (In colname list) = 
        (\row -> ((row!!(getElemPos' colname colNames)) `elem` list) == True)
    
    feval colNames (FNot (Eq colname ref)) = 
        (\row -> not(((row!!getElemPos' colname colNames)) == ref))
    feval colNames (FNot (Lt colname ref)) = 
        (\row -> not(((row!!getElemPos' colname colNames)) < ref))
    feval colNames (FNot (Gt colname ref)) =
        (\row -> not(((row!!getElemPos' colname colNames)) > ref))
    feval colNames (FNot (In colname list)) = 
        (\row -> not(((row!!(getElemPos' colname colNames)) `elem` list) == True))

    feval colNames (FieldEq colname1 colname2) = 
        (\row -> (row!!(getElemPos' colname1 colNames)) == (row!!(getElemPos' colname2 colNames)))


{-- 
formula pentru combinari de ns luate cate k (prima tentativa)
combinations k ns = filter ((k==).length) $ subsequences ns

-- intoarce lista de Just si Nothing in urma aplicarii functiei pe cele 2 tabele (Debug)
cartesian' :: EdgeOp -> [String] -> Table -> Table -> [Maybe Value]
cartesian' func' nList t1 t2 = 
    map (\list -> func' (head list) (last list)) (sequence [tail t1, tail t2])
--}

-- where EdgeOp is defined:
type EdgeOp = Row -> Row -> Maybe Value

-- functie ce intoarce tabelul final modificat
modifiedTab' :: EdgeOp -> Table -> Table
modifiedTab' func' t1 = ["From", "To", "Value"] : (foldr (\list acc -> 
    if ((func' (head list) (last list)) /= Nothing) 
        then ((createRow' (func' (head list) (last list)) list):acc) 
        else acc) [] (createGroups' (tail t1)))

-- functia de generare a tuturor perechilor de 2 linii din tabel 
createGroups' :: [a] -> [[a]]
createGroups' [] = []
createGroups' (x:xs) = (map (\elem -> [x, elem]) xs) ++ createGroups' xs

updateGroups :: [Table] -> Table
updateGroups tabs = foldr (\tab acc -> [(head tab)++(last tab)]++acc) [] tabs

-- functia de eliminare a liniilor ce contin acelasi nume in From si To din tabel
delEqRows' :: Table -> Table
delEqRows' = foldr (\list acc ->
     if ((head list) == head(tail list)) then acc else list:acc) []

-- functia de creare a unui rand din tabelul final
createRow' :: Maybe Value -> [Row] -> Row
createRow' value rowslist = 
    (compTwoElems' (head(head rowslist)) (head(last rowslist)))
    ++ ((fromJust(value)) : [])

-- functie de creare a unei liste cu elem e1 si e2 sortate lexicografic
compTwoElems' :: Value -> Value -> [Value]
compTwoElems' e1 e2 = 
    if (e1 < e2) then (e1 : e2 : []) else (e2 : e1 : [])

-- Task 3.6

-- functia de sortare in functie de valoare si lexicografic
sortTable [from1, to1, val1] [from2, to2, val2]
    | readInteger' val1 < readInteger' val2 = LT
    | readInteger' val1 > readInteger' val2 = GT
    | otherwise = if (from1 < from2) then LT 
                  else if (from1 > from2) then GT 
                    else EQ

-- functie ce intoarce tabelul final modificat
modifiedTab1' :: (Row -> Row -> [Row]) -> Table -> Table
modifiedTab1' func1' t1 = ["From", "To", "Value"] : 
    (sortBy sortTable (foldr (\list acc -> 
    if (questionsSum'(func1' (head list) (last list)) >= 5) 
        then ((createRow1' (questionsSum'(func1' (head list) (last list))) list):acc) 
        else acc) [] (createGroups' (tail t1))))

-- functie de combinare a doua randuri in perechi sub forma de tabele
-- pentru verificarea ulterioara a sumei intrebarilor cu punctaj identic 
-- (puteam folosi chiar perechi)
func1' :: Row -> Row -> [Row]
func1' r1 r2 = zipWith (\row1 row2 -> row1:(row2:[])) r1 r2

-- determina distanta dintre 2 studenti
-- caracterizata de suma intrebarilor la care amandoi au primit acelsai punctaj
questionsSum' :: [Row] -> Integer
questionsSum' list = 
    if ((head(head list) /= last(head list)) && (head(head list) /= "") && (last(head list) /= ""))
        then (foldr (\elem acc -> 
            if (head(elem) == last(elem)) 
                then acc + 1 
                else acc) 0 list)
        else 0

-- functia de creare a unui rand din tabelul final
createRow1' :: Integer -> [Row] -> Row
createRow1' value rowslist = 
    (compTwoElems' (head(head rowslist)) (head(last rowslist)))
    ++ ((show value) : [])

similarities_query :: Query
similarities_query = FromCSV (write_csv(modifiedTab1' func1' lecture_grades))

-- ================================================================================================
-- Task Set 4

correct_table :: String -> CSV -> CSV -> CSV
correct_table str csv1 csv2 = 
    write_csv(restoreTable' str (read_csv csv1) (finalFilter' str (read_csv csv1) (read_csv csv2)))

-- sortarea unui tabel in ordine lexicografica a..z deoarece
-- implementarea trebuie sa fie generica si sa nu depinda de ordinea randurilor
compareRows row1 row2
    | (head row1) < (head row2) = LT
    | (head row1) > (head row2) = GT
    | otherwise = EQ
sortTab' :: Table -> Table
sortTab' tab = (head tab) : (sortBy compareRows (tail tab))

-- extragerea coloanei str din ambele tabele pentru a vedea diferentele dintre T si Ref
extractTandRefCols' :: String -> Table -> Table -> Table
extractTandRefCols' str t1 t2 = ["T", "Ref"] :
    tail(tran'((getEntireColumn' str (t1)) : (getEntireColumn' str (t2)) : []))

-- pastrarea valorilor care contin typo-uri si analoagele lor corecte
filterTypos' :: Table -> Table
filterTypos' = filter (\row -> head(row) /= last(row))

-- determinarea similaritatii dintre cele 2 stringuri prin verificarea
-- diferentei celor 2 lungimi (T si Ref) care sa nu depaseasca valoarea 3
getDistance' :: Table -> Table
getDistance' = filter (\row -> abs(length(head row) - length(last row)) <= 3)

-- matricea ce indeplineste conditiile impuse de getDistance', filterTypos' si extractTandRefCols'
finalFilter' :: String -> Table -> Table -> Table
finalFilter' str t1 t2 = getDistance' $ filterTypos' $ extractTandRefCols' str t1 t2

-- t1 este tabelul cu typo-uri pe care il vom actualiza in mod corect,
-- t2 reprezinta tabelul cu valorile ce contin typo-uri si corespondentul
-- acestor typo-uri cu care vom inlocui in tabelul t1 (str reprezinta coloana pe care o prelucrez)
restoreTable' :: String -> Table -> Table -> Table
restoreTable' str t1 t2 = (["Nume","Email"]) :
    foldr (\x acc -> 
        if (x `elem` (as_list "T" t2)) 
            then 
            (last(t2!!(findPos' x "T" t2)) : (tail (t1!!(findPos' x str t1)))):acc 
            else
            (t1!!(findPos' x str t1)):acc) [] (as_list str t1)

tab11 = [["Nume", "Email"], ["Rau Cristi", "raducristi@yahoo.com"], ["Anem Marie", "anamaria@gmail.com"],
    ["Andrei Radu", "andreiradu@gmail.com"]]
tab22 = [["T", "Ref"], ["Rau Cristi", "Radu Cristi"], ["Anem Marie", "Ana Marie"]]



grades :: CSV -> CSV -> CSV -> CSV -> CSV
grades = undefined