{-
	PP Project 2021

	This is where you will write the implementation for the given tasks.
	You can add other modules aswell.
-}

module Tasks where

import Dataset
import Text.Printf
import Data.List

type CSV = String
type Value = String
type Row = [Value]
type Table = [Row]

{-
	TASK SET 1
-}

readFloat' :: String -> Float
readFloat' "" = 0.0
readFloat' elem = (read elem) :: Float

readInteger' :: String -> Integer
readInteger' "" = 0
readInteger' elem = (read elem) :: Integer

readInt' :: String -> Int
readInt' "" = 0
readInt' elem = (read elem) :: Int

-- Task 1
compute_exam_grades :: Table -> Table
compute_exam_grades = map requestedFormat'

l1' = ["Riley Jackson","2","2","2","2","2","1","Ex. Scris"]
l1'' = ["Kinsley Miles","","","","","","","0.13"]
l1''' = ["","","","","",""]


-- auxFunctie ce intoarce formatul cerut pentru o lista
requestedFormat' :: Row -> Row
requestedFormat' l 
    | last(l) == "Ex. Scris" = ["Nume"] ++ ["Punctaj Exam"]
    | otherwise = [head(l)] ++ [printf "%.2f" (formula' l)]

-- formula de calcul enuntata (sumInteger')/4+Ex.scris unde sumInteger' este (Q1+Q2+Q3+Q4+Q5+Q6)
formula' :: Row -> Float
formula' l = (fromIntegral(sumInteger' (init (tail l))) / 4) + (readFloat' (last l))

-- calculeaza suma elementelor unei liste cu elemete Integer
sumInteger' :: Row -> Integer
sumInteger' l = 
    foldl (\acc elem -> if (elem == []) then acc else (readInteger' elem) + acc) 0 l

l2' = [["Olivia Noah","0","0","2","2","2","2","0.93"],
    ["Riley Jackson","2","2","2","2","2","1","1.2"],
    ["Elizabeth Nathan","1","1","2","1","0","2","0.8"],
    ["Kinsley Miles","","","","","","","0.13"]]

-- Task 2
-- Number of students who have passed the exam:
get_passed_students_num :: Table -> Int
get_passed_students_num = 
    foldl (\acc l -> if((readFloat' (last(l))) > 2.50) then acc + 1 else acc) 0 .
    tail .
    compute_exam_grades


-- Percentage of students who have passed the exam:
get_passed_students_percentage :: Table -> Float
get_passed_students_percentage = printauxFunction' . calculatePercentage'

-- formula pentru determinarea procentajului de studenti care au trecut
calculatePercentage' :: Table -> Float
calculatePercentage' l = 
    fromIntegral(get_passed_students_num l) / fromIntegral((length l) - 1) 

-- auxFunctie de afisare ca float cu 2 zecimale
printauxFunction' :: Float -> Float
printauxFunction' x = read (printf "%.2f" x) :: Float

-- Average exam grade
get_exam_avg :: Table -> Float
get_exam_avg = printauxFunction' . computeAvg'

computeSum' :: Table -> Float
computeSum' list = foldl (\acc l -> ((readFloat' (last l))) + acc) 0.0 (tail list)

computeAvg' :: Table -> Float
computeAvg' l = printauxFunction'(computeSum' (compute_exam_grades l)) / fromIntegral((length l) - 1)

-- Number of students who gained at least 1.5p from homework:
get_passed_hw_num :: Table -> Int
get_passed_hw_num = checkCond'

-- verificarea conditiei si returnarea numarului de studenti cu temele in valoare de "minim" 1.5p
checkCond' :: Table -> Int
checkCond' list = 
    foldl (\acc l -> if ((printauxFunction' (hwTotalT1T2T3' l)) >= 1.5) then acc + 1 else acc) 0 (tail(list))

-- auxFunctia care calculeza suma celor 3 teme
hwTotalT1T2T3' :: Row -> Float
hwTotalT1T2T3' l = sumFloat' (take 3 (tail(tail l)))

-- calculeaza suma elementelor unei liste cu elemete Float
sumFloat' :: Row -> Float
sumFloat' l = 
    foldl (\acc elem -> if (elem == []) then acc else (readFloat' elem) + acc) 0.00 l

-- Task 3
get_avg_responses_per_qs :: Table -> Table
get_avg_responses_per_qs = showInFormat3'

-- calculeaza suma punctajelor pentru o intrebare Qx
-- getSumQx' :: Int -> Table -> Integer
-- getSumQx' pos list = foldl (\acc l -> (readInteger' (l !! pos)) + acc) 0 list

-- auxFunctia ce intoarce lista in formatul conform task-ului
showInFormat3' :: Table -> Table
showInFormat3' list = [(init(tail(head list)))] ++ [(map show (createAvgList' list))]

-- auxFunctia care intoarce o lista de integer reprezentand sumele totale ale intrebarilor
createAvgList' :: Table -> [Float]
createAvgList' list = 
    foldr (avg) [] (init (tail (tran' (tail(list)))))
    where avg = \l acc -> (printauxFunction'(fromIntegral(sumInteger'(l)) / 
                          fromIntegral((length list) - 1))):acc

-- auxFunctie care efectueaza transpunerea unei matrice
tran' :: [[a]] -> [[a]]
tran' ([]:_) = []
tran' m = (map head m) : tran' (map tail m)

-- Task 4
-- intoarce Tabelul in formatul specificat
get_exam_summary :: Table -> Table
get_exam_summary tab = ["Q","0","1","2"]:(adjustList' (createLists' (init(tail(tran'(tail(tab)))))) 1)

-- converteste o lista de Integer la o lista de String
integerListToRow' :: [Integer] -> Row
integerListToRow' = foldr (\elem acc -> (show elem):acc) []

-- creeaza lista cu numarul de elemente de 0, 1 si 2 din lista initiala
createList' :: Row -> [Integer]
createList' = foldr (\elem acc -> 
            if(readInteger'(elem) == 0) then ((head acc) + 1):(tail acc) 
            else if(readInteger'(elem) == 1) then (head acc):(head(tail acc) + 1):[last acc]
                 else (init acc)++[(last acc) + 1]) [0, 0, 0]

-- aplica tuturor listelor din tabel auxFunctia anterioara convertind listele la [String]
createLists' :: Table -> Table
createLists' = foldr (\list acc -> integerListToRow'(createList' list):acc) []

-- adauga Qx (unde x este 1..6) la fiecare lista din tabel
adjustList' :: Table -> Integer -> Table 
adjustList' [] y = []
adjustList' (x:xs) y = (("Q" ++ (show y)):x) : (adjustList' xs (y + 1))

-- Task 5
get_ranking :: Table -> Table
get_ranking res = ["Nume","Punctaj Exam"]:(sortStudents' $tail(compute_exam_grades res))

-- auxFunctii de comparare pentru nume si pentru medie
compareGrades [name1, grade1] [name2, grade2]
    | grade1 < grade2 = LT
    | grade1 > grade2 = GT
    | otherwise = EQ

compareNames [name1, grade1] [name2, grade2]
    | name1 < name2 = LT
    | name1 > name2 = GT
    | otherwise = EQ

-- sortare dupa nume si medie
sortStudents' :: Table -> Table
sortStudents' l = sortBy compareGrades (sortBy compareNames l)

-- Task 6
get_exam_diff_table :: Table -> Table
get_exam_diff_table res = ["Nume","Punctaj interviu","Punctaj scris","Diferenta"] :
            (sortBy compareDiff (sortBy compareNames1 (map requestedFormat6' (tail res))))

-- formula de calcul enuntata (sumInteger')/4 unde sumInteger' este (Q1+Q2+Q3+Q4+Q5+Q6)
formula6' :: Row -> Float
formula6' l = fromIntegral(sumInteger' (init (tail l))) / 4

-- auxFunctie ce intoarce formatul cerut pentru o lista
requestedFormat6' :: Row -> Row
requestedFormat6' l = [head(l)] ++ [printf "%.2f" (formula6' l)] ++ 
                  [printf "%.2f" (readFloat' (last l))] ++ 
                  [printf "%.2f" (abs((formula6' l) - (readFloat' (last l))))]

-- auxFunctii de comparare pentru nume si pentru
--  diferenta a 2 numere din liste de tipul specificat
compareDiff [name1, interview1, write1, diff1] [name2, interview2, write2, diff2]
    | diff1 < diff2 = LT
    | diff1 > diff2 = GT
    | otherwise = EQ

compareNames1 [name1, interview1, write1, diff1] [name2, interview2, write2, diff2]
    | name1 < name2 = LT
    | name1 > name2 = GT
    | otherwise = EQ

-- ================================================================================================
-- Task Set 2

test0 = "\
    \Nume,Q1,Q2,Q3,Q4,Q5,Q6,Ex. Scris\n\
    \Olivia Noah,0,0,2,2,2,2,0.93\n\
    \Kinsley Miles,,,,,,,0.13\n\
    \Joshua Kennedy,1,2,2,2,1,2,0.67"

-- auxFunctie de split in auxFunctie de caracter dat ca param.
splitBy :: Char -> String -> [String] 
splitBy ch = foldr (\elem acc -> if (elem == ch) then []:acc
             else (elem:(head acc)) : (tail acc)) [[]] 

-- auxFunctie de transformare din csv in tipul Table
read_csv :: CSV -> Table
read_csv csv = map (splitBy ',') $ splitBy '\n' $ csv

rowToValue :: Row -> Value
rowToValue = init . foldr (\elem acc -> (elem ++ ',' : acc)) ""

-- auxFunctie de transformare din tipul table in csv
write_csv :: Table -> CSV
write_csv = init . foldr (\elem acc -> (rowToValue elem) ++ '\n' : acc) ""

-- lista ce contine capetele de tabel al listelor din Dataset.hs
namesListOfLists = [hw_grades!!0, exam_grades!!0, lecture_grades!!0]

-- Task 1
as_list :: String -> Table -> [String]
as_list colName table = map (!!(getElemPos' colName (head table))) (tail table)

-- determina prima pozitie pe care apare un element dat ca param. intr-o lista
-- cu cel putin un elem.
getElemPos' :: String -> Row -> Int
getElemPos' str (x:xs) = head(elemIndices str (x:xs))

-- Task 2
tsort :: String -> Table -> Table
tsort str1 table1 = auxSort' str1 (auxSort' (head(head table1)) table1)

-- realizeaza sortarea unui tabel in functie de un element continut de
-- listele acestuia
auxSort' :: String -> Table -> Table
auxSort' str table = (head table) :
    (sortBy (\list1 list2 -> compare (list1!!(getElemPos' str (head table))) 
    (list2!!(getElemPos' str (head table)))) (tail table))

-- Task 3
vmap :: (Value -> Value) -> Table -> Table
vmap auxFunction table = map (\list -> map auxFunction list) table
-- An example use of this would be:
-- correct_exam_table = value_map (\x -> if x == "" then "0" else x) exam_grades

-- Task 4
rmap :: (Row -> Row) -> [String] -> Table -> Table
rmap auxFunction namesList table = namesList : (map auxFunction (tail table))

l4' = ["Olivia Noah","0.42","0.49","1","1.05","","","0",""]
l4'' = ["Emma Aiden","","0.5","1","0.9","","","0",""]

get_hw_grade_total :: Row -> Row
get_hw_grade_total row = (head row) : [printf "%.2f" ((sumFloat' (tail(tail row))) :: Float) :: String]

-- Task 5
vunion :: Table -> Table -> Table
vunion t1 t2 = if ((head t1) == (head t2)) then t1 ++ (tail t2) else t1

-- Task 6
hunion :: Table -> Table -> Table
hunion t1 t2
    | (length t1) > (length t2) = 
        zipWith (++) t1 (t2 ++ (replicate ((length t1) - (length t2)) (replicate (length (head t2)) "")))
    | (length t1) < (length t2) = 
        zipWith (++) (t1 ++ (replicate ((length t2) - (length t1)) (replicate (length (head t1)) ""))) t2
    | otherwise = zipWith (++) t1 t2


-- Nu am mai avut sa-mi dau seama exact care ar fii implementarea potrivita pentru acest exercitiu !
-- Task 7
tjoin :: String -> Table -> Table -> Table
tjoin str t1 t2 = if ((str `elem` (head t1)) == True && (str `elem` (head t2)) == True) then (hunion t1 (createSimpleTable' str t2)) else (hunion t1 t2)

-- intoarce tabelul fara coloana specificata
createSimpleTable' :: String -> Table -> Table
createSimpleTable' str table = tran' (foldr (\list acc -> if ((head list) == str) then acc else list : acc) [] (tran' table))

-- Task 8
cartesian :: (Row -> Row -> Row) -> [String] -> Table -> Table -> Table
cartesian func' nList t1 t2 = nList : map (\list -> func' (head list) (last list)) (sequence [tail t1, tail t2])

-- Task 9
projection :: [String] -> Table -> Table
projection nList table = tran' (foldr (\name acc -> (getEntireColumn' name table) : acc) [] nList)

-- intoarce o coloana inclusiv denumirea acesteia spre deosebire de task 1;
-- se foloseste de getElemPos' de la task 1
getEntireColumn' :: String -> Table -> [String]
getEntireColumn' colName table = map (!!(getElemPos' colName (head table))) table

-- ================================================================================================